import React, { useState, useEffect } from 'react';
import { SPK, Role, AppNotification, BackupLog, RolePin } from './types';
import { INITIAL_SPKS, INITIAL_NOTIFICATIONS, INITIAL_BACKUP_LOGS } from './data/initialData';
import DashboardStats from './components/DashboardStats';
import DataAnalysisPanel from './components/DataAnalysisPanel';
import SPKForm from './components/SPKForm';
import SPKList from './components/SPKList';
import RoleLogin from './components/RoleLogin';
import BackupPanel from './components/BackupPanel';
import RoleLoginModal from './components/RoleLoginModal';
import { Shield, Bell, Check, Trash2, Calendar, HardDrive, Key, AlertTriangle, Cloud, UserCheck, KeyRound } from 'lucide-react';

export default function App() {
  // --- States with LocalStorage Persistence ---
  const [spks, setSpks] = useState<SPK[]>(() => {
    const saved = localStorage.getItem('spk_data');
    return saved ? JSON.parse(saved) : INITIAL_SPKS;
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem('spk_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [logs, setLogs] = useState<BackupLog[]>(() => {
    const saved = localStorage.getItem('spk_backup_logs');
    return saved ? JSON.parse(saved) : INITIAL_BACKUP_LOGS;
  });

  const [pins, setPins] = useState<RolePin>(() => {
    const saved = localStorage.getItem('spk_role_pins');
    return saved ? JSON.parse(saved) : { Teknik: '1111', SPV: '2222', Head: '3333' };
  });

  const [currentRole, setCurrentRole] = useState<Role>('Pelapor');
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeTab, setActiveTab] = useState<'monitoring' | 'pengajuan' | 'backup' | 'analisa'>('pengajuan');
  const [showRoleModal, setShowRoleModal] = useState<boolean>(true);
  const [selectedSpkId, setSelectedSpkId] = useState<string | undefined>(undefined);

  // --- Auth / Role selector handler ---
  const handleAuthenticate = (role: Role) => {
    setCurrentRole(role);
    setShowRoleModal(false);
    if (role === 'Pelapor') {
      setActiveTab('pengajuan');
    } else {
      setActiveTab('monitoring');
    }
  };

  const handleRoleChange = (role: Role) => {
    setCurrentRole(role);
    if (role === 'Pelapor') {
      setActiveTab('pengajuan');
    } else {
      setActiveTab('monitoring');
    }
  };

  // --- Save states to localStorage on changes ---
  useEffect(() => {
    localStorage.setItem('spk_data', JSON.stringify(spks));
  }, [spks]);

  useEffect(() => {
    localStorage.setItem('spk_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('spk_backup_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('spk_role_pins', JSON.stringify(pins));
  }, [pins]);

  // --- Core Workflows / Handlers ---

  // 1. Submit SPK
  const handleAddSPK = (newSPK: SPK) => {
    setSpks(prev => [newSPK, ...prev]);

    // Send real-time notification to Head & SPV
    const notifId = `notif-${Date.now()}`;
    const newNotif: AppNotification = {
      id: notifId,
      title: "SPK Baru Diajukan",
      message: `${newSPK.diajukanOleh} (${newSPK.bagian}) mengajukan SPK untuk ${newSPK.namaMesin}.`,
      timestamp: new Date().toISOString(),
      role: 'Head',
      read: false,
      spkId: newSPK.id
    };
    setNotifications(prev => [newNotif, ...prev]);

    // Auto backup logging
    logAutoBackup(`Pengajuan SPK baru (${newSPK.id}) ditambahkan. Sistem otomatis mengantrekan pencadangan.`);
  };

  // 1b. ACC Head Departemen Terkait
  const handleApproveDeptHead = (spkId: string, deptHeadName: string) => {
    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        return {
          ...s,
          approvedByDeptHead: true,
          deptHeadName,
          approvedByDeptHeadAt: new Date().toISOString()
        };
      }
      return s;
    }));

    // Notify Head Teknik / Admin
    const targetSPK = spks.find(s => s.id === spkId);
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: "ACC Head Departemen",
      message: `SPK ${spkId} (${targetSPK?.namaMesin || 'Mesin'}) telah di-ACC oleh Head Departemen Terkait (${deptHeadName}). Menunggu approval Head Teknik.`,
      timestamp: new Date().toISOString(),
      role: 'Head',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`SPK ${spkId} di-ACC oleh Head Departemen Terkait ${deptHeadName}.`);
  };

  // 2. Approve SPK (By Head)
  const handleApproveSPK = (spkId: string, headName: string) => {
    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        const approvedAt = new Date().toISOString();
        // Calculate response time from submission
        const createdTime = new Date(s.createdAt).getTime();
        const approvedTime = new Date(approvedAt).getTime();
        const approvalDurationMinutes = Math.round((approvedTime - createdTime) / 60000);

        return {
          ...s,
          status: 'Approved',
          approvedAt,
          approvedBy: headName,
          approvalDurationMinutes
        };
      }
      return s;
    }));

    // Notify Teknik
    const targetSPK = spks.find(s => s.id === spkId);
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: "SPK Disetujui Head",
      message: `SPK ${spkId} (${targetSPK?.namaMesin}) disetujui Head. Teknisi dapat memulai perbaikan.`,
      timestamp: new Date().toISOString(),
      role: 'Teknik',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`SPK ${spkId} disetujui oleh ${headName}. Status diperbarui di cloud database.`);
  };

  // 3. Reject SPK (By Head)
  const handleRejectSPK = (spkId: string, headName: string, reason: string) => {
    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        return {
          ...s,
          status: 'Rejected',
          rejectedAt: new Date().toISOString(),
          rejectedBy: headName,
          rejectionReason: reason
        };
      }
      return s;
    }));

    // Notify All
    const targetSPK = spks.find(s => s.id === spkId);
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: "SPK Ditolak Head",
      message: `SPK ${spkId} (${targetSPK?.namaMesin}) ditolak. Alasan: ${reason}`,
      timestamp: new Date().toISOString(),
      role: 'All',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`SPK ${spkId} ditolak oleh ${headName}. Alasan: ${reason}.`);
  };

  // 4. Report Repair Action (By Teknik)
  const handleReportRepair = (
    spkId: string,
    teknisi: string,
    tindakan: string,
    statusChoice: 'Menunggu Sparepart' | 'Menunggu Verifikasi',
    tanggalPerbaikan: string,
    jenisPekerjaan: 'Perbaikan' | 'Maintenance' | 'Pengecekan'
  ) => {
    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        const perbaikanSelesaiAt = new Date().toISOString();
        let repairDurationMinutes = s.repairDurationMinutes;

        // If completed & submitted for verification, calculate repair duration from Approval
        if (statusChoice === 'Menunggu Verifikasi' && s.approvedAt) {
          const approvedTime = new Date(s.approvedAt).getTime();
          const finishedTime = new Date(perbaikanSelesaiAt).getTime();
          repairDurationMinutes = Math.round((finishedTime - approvedTime) / 60000);
        }

        return {
          ...s,
          status: statusChoice,
          tindakPerbaikan: tindakan,
          teknisiNama: `${teknisi} (Teknik)`,
          perbaikanSelesaiAt: statusChoice === 'Menunggu Verifikasi' ? perbaikanSelesaiAt : undefined,
          repairDurationMinutes,
          tanggalPerbaikan,
          jenisPekerjaan,
          // Reset verification tags on edit
          verifiedBySPV: false,
          verifiedByHead: false
        };
      }
      return s;
    }));

    // Notify SPV and Head
    const targetSPK = spks.find(s => s.id === spkId);
    const title = statusChoice === 'Menunggu Sparepart' ? 'Kebutuhan Sparepart SPK' : 'Laporan Kerja Selesai';
    const message = statusChoice === 'Menunggu Sparepart'
      ? `${teknisi} melaporkan SPK ${spkId} (${targetSPK?.namaMesin}) tertunda: Menunggu Sparepart.`
      : `${teknisi} menyelesaikan perbaikan SPK ${spkId} (${targetSPK?.namaMesin}). Menunggu Verifikasi SPV & Head.`;

    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title,
      message,
      timestamp: new Date().toISOString(),
      role: statusChoice === 'Menunggu Sparepart' ? 'SPV' : 'All',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`Laporan tindakan perbaikan SPK ${spkId} dikirim oleh teknisi ${teknisi}.`);
  };

  // 5. Verify SPV
  const handleVerifySPV = (spkId: string, spvName: string) => {
    let closedAutomatically = false;

    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        const isClosedNow = s.verifiedByHead; // Closed if Head has also verified
        if (isClosedNow) closedAutomatically = true;
        return {
          ...s,
          verifiedBySPV: true,
          verifiedBySPVNama: spvName,
          verifiedBySPVAt: new Date().toISOString(),
          status: isClosedNow ? 'Closed' : s.status
        };
      }
      return s;
    }));

    // Notify Head
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: "Verifikasi SPV Selesai",
      message: `SPV ${spvName} memverifikasi pekerjaan SPK ${spkId}. ${closedAutomatically ? 'Status SPK resmi ditutup (Closed).' : 'Menunggu verifikasi Head.'}`,
      timestamp: new Date().toISOString(),
      role: 'Head',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`Verifikasi SPV selesai untuk SPK ${spkId} oleh ${spvName}.`);
  };

  // 6. Verify Head
  const handleVerifyHead = (spkId: string, headName: string) => {
    let closedAutomatically = false;

    setSpks(prev => prev.map(s => {
      if (s.id === spkId) {
        const isClosedNow = s.verifiedBySPV; // Closed if SPV has also verified
        if (isClosedNow) closedAutomatically = true;
        return {
          ...s,
          verifiedByHead: true,
          verifiedByHeadNama: headName,
          verifiedByHeadAt: new Date().toISOString(),
          status: isClosedNow ? 'Closed' : s.status
        };
      }
      return s;
    }));

    // Notify SPV / All
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: "Verifikasi Head Selesai",
      message: `Head ${headName} memverifikasi pekerjaan SPK ${spkId}. ${closedAutomatically ? 'Status SPK resmi ditutup (Closed).' : 'Menunggu verifikasi SPV.'}`,
      timestamp: new Date().toISOString(),
      role: 'SPV',
      read: false,
      spkId
    };
    setNotifications(prev => [newNotif, ...prev]);
    logAutoBackup(`Verifikasi Head selesai untuk SPK ${spkId} oleh ${headName}.`);
  };

  // 7. Manual or automated Backup triggers
  const handleTriggerBackup = (type: 'Firebase' | 'Google Spreadsheet') => {
    const newLog: BackupLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type,
      status: 'Sukses',
      recordsSynced: spks.length,
      details: type === 'Firebase'
        ? `Berhasil mengunggah dokumen baru ke Firestore cloud. Koleksi 'spks' sinkron sempurna.`
        : `Sinkronisasi baris data ke Google Spreadsheet Workspace berhasil. Seluruh ${spks.length} record aman.`
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const logAutoBackup = (eventDetails: string) => {
    const timestamp = new Date().toISOString();
    const newLogs: BackupLog[] = [
      {
        id: `log-${Date.now()}-f`,
        timestamp,
        type: 'Firebase',
        status: 'Sukses',
        recordsSynced: spks.length + 1,
        details: `Auto-sync: ${eventDetails}`
      },
      {
        id: `log-${Date.now()}-g`,
        timestamp,
        type: 'Google Spreadsheet',
        status: 'Sukses',
        recordsSynced: spks.length + 1,
        details: `Row updated: ${eventDetails}`
      }
    ];
    setLogs(prev => [...newLogs, ...prev]);
  };

  // 8. Export to XLS
  const handleExportXLS = () => {
    let html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>Data SPK TEKNIK GIT</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body { font-family: Arial, sans-serif; }
          h2 { color: #1e3a8a; }
          table { border-collapse: collapse; width: 100%; margin-top: 15px; }
          th { background-color: #1e3a8a; color: #ffffff; font-weight: bold; padding: 10px; border: 1px solid #cbd5e1; font-size: 11px; text-align: left; }
          td { padding: 8px; border: 1px solid #cbd5e1; font-size: 11px; }
          .title-row { font-size: 16px; font-weight: bold; text-align: center; }
          .badge-pending { background-color: #fef3c7; color: #d97706; }
          .badge-approved { background-color: #dbeafe; color: #2563eb; }
          .badge-rejected { background-color: #fee2e2; color: #dc2626; }
          .badge-sparepart { background-color: #ffedd5; color: #ea580c; }
          .badge-verif { background-color: #f3e8ff; color: #9333ea; }
          .badge-closed { background-color: #dcfce7; color: #16a34a; }
        </style>
      </head>
      <body>
        <div style="text-align: center; margin-bottom: 20px;">
          <h2>LAPORAN SURAT PERINTAH KERJA (SPK)</h2>
          <p>Sistem Pengawasan Terintegrasi | Tanggal Ekspor: ${new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
        <table>
          <thead>
            <tr>
              <th>No SPK</th>
              <th>Tanggal Pengajuan</th>
              <th>Nama Mesin / Alat</th>
              <th>Diajukan Oleh</th>
              <th>Bagian (Dept)</th>
              <th>Deskripsi Kerusakan</th>
              <th>Status SPK</th>
              <th>Tindak Perbaikan</th>
              <th>Teknisi Pelaksana</th>
              <th>Waktu Approval (Menit)</th>
              <th>Waktu Perbaikan (Menit)</th>
              <th>Verifikasi SPV</th>
              <th>Verifikasi Head</th>
            </tr>
          </thead>
          <tbody>
            ${spks.map(s => `
              <tr>
                <td style="font-weight: bold; font-family: monospace;">${s.id}</td>
                <td>${s.tanggalPengajuan}</td>
                <td style="font-weight: bold;">${s.namaMesin}</td>
                <td>${s.diajukanOleh}</td>
                <td>${s.bagian}</td>
                <td>${s.deskripsiMasalah}</td>
                <td class="badge-${
                  s.status === 'Closed' ? 'closed' :
                  s.status === 'Rejected' ? 'rejected' :
                  s.status === 'Menunggu Sparepart' ? 'sparepart' :
                  s.status === 'Menunggu Verifikasi' ? 'verif' :
                  s.status === 'Approved' ? 'approved' : 'pending'
                }">${s.status}</td>
                <td>${s.tindakPerbaikan || '-'}</td>
                <td>${s.teknisiNama || '-'}</td>
                <td style="font-family: monospace; text-align: right;">${s.approvalDurationMinutes !== undefined ? s.approvalDurationMinutes : '-'}</td>
                <td style="font-family: monospace; text-align: right;">${s.repairDurationMinutes !== undefined ? s.repairDurationMinutes : '-'}</td>
                <td>${s.verifiedBySPV ? `SUDAH (${s.verifiedBySPVNama})` : 'BELUM'}</td>
                <td>${s.verifiedByHead ? `SUDAH (${s.verifiedByHeadNama})` : 'BELUM'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Laporan_Sistem_SPK_${new Date().toISOString().split('T')[0]}.xls`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // 8b. Reset Data (Kosongkan Semua Data)
  const handleResetData = () => {
    setSpks([]);
    setNotifications([]);
    setLogs([]);
    localStorage.removeItem('spk_data');
    localStorage.removeItem('spk_notifications');
    localStorage.removeItem('spk_backup_logs');
  };

  // 9. Change PIN
  const handleChangePin = (role: 'Teknik' | 'SPV' | 'Head', newPin: string) => {
    setPins(prev => ({
      ...prev,
      [role]: newPin
    }));
    logAutoBackup(`PIN keamanan untuk hak akses ${role} berhasil dirubah oleh pengguna.`);
  };

  // 10. Clear notifications
  const handleClearNotifications = () => {
    setNotifications([]);
  };

  // 11. Mark all as read
  const handleMarkNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Filter notifications based on active role permissions
  const visibleNotifs = notifications.filter(n => {
    if (n.role === 'All' || n.role === currentRole) return true;
    if (currentRole === 'Head') return true; // Head sees all logs
    return false;
  });

  const unreadCount = visibleNotifs.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#E0E0E0] font-sans" id="spk-applet">
      
      {/* PROFESSIONAL NAVBAR */}
      <nav className="sticky top-0 z-40 bg-[#161B22]/90 border-b border-white/10 shadow-lg shadow-black/10 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            {/* Logo/Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h1 className="font-extrabold text-white text-sm tracking-tight sm:text-base">TEKNIK GIT</h1>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                  Approval Berjenjang & Real-Time Sync
                </p>
              </div>
            </div>

            {/* Navigation tabs */}
            {currentRole !== 'Pelapor' ? (
              <div className="hidden md:flex space-x-1 bg-white/5 p-1.5 rounded-xl border border-white/10">
                <button
                  onClick={() => setActiveTab('monitoring')}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                    activeTab === 'monitoring'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/10'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Monitoring & Tindakan
                </button>
                <button
                  onClick={() => setActiveTab('pengajuan')}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                    activeTab === 'pengajuan'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/10'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Buat SPK Baru
                </button>
                <button
                  onClick={() => setActiveTab('analisa')}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                    activeTab === 'analisa'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/10'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Panel Analisa Data
                </button>
                <button
                  onClick={() => setActiveTab('backup')}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                    activeTab === 'backup'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/10'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Skema Cloud Backup
                </button>
              </div>
            ) : (
              /* If Pelapor, we show an informative indicator badge */
              <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/25 rounded-xl text-xs font-semibold text-blue-400">
                <Cloud className="w-4 h-4 text-blue-400" />
                <span>Pelindung Kuota Firebase Aktif (Offline Cache-Shield)</span>
              </div>
            )}

            {/* Notification Pane and User badge */}
            <div className="flex items-center gap-4">
              
              {/* Firebase Quota Shield Badge (Always visible on large screens) */}
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-green-500/10 border border-green-500/25 text-green-400 rounded-xl text-xs font-bold">
                <HardDrive className="w-3.5 h-3.5 text-green-400 animate-pulse" />
                <span>Quota Guard: 100% Aman</span>
              </div>

              {/* Notification bell - only for staff/dashboard roles */}
              {currentRole !== 'Pelapor' && (
                <div className="relative">
                  <button
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="p-2 text-gray-400 hover:text-white bg-white/5 border border-white/10 rounded-xl transition hover:bg-white/10 cursor-pointer flex items-center"
                    id="btn-notif-bell"
                  >
                    <Bell className="w-4 h-4" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                        {unreadCount}
                      </span>
                    )}
                  </button>

                  {/* Notifications Panel Dropdown */}
                  {showNotifications && (
                    <div className="absolute right-0 mt-3 w-80 bg-[#161B22] border border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden animate-slideDown" id="notif-dropdown">
                      <div className="p-3.5 bg-[#0F1115] text-white flex justify-between items-center text-xs border-b border-white/10">
                        <span className="font-bold flex items-center gap-1.5">
                          <Bell className="w-3.5 h-3.5 text-blue-400" />
                          Notifikasi Real-Time
                        </span>
                        <div className="flex gap-2">
                          {visibleNotifs.length > 0 && (
                            <button onClick={handleMarkNotificationsRead} className="text-[10px] text-blue-400 hover:text-white font-medium cursor-pointer">
                              Tandai Dibaca
                            </button>
                          )}
                          <button onClick={handleClearNotifications} className="text-[10px] text-red-400 hover:text-red-300 font-medium cursor-pointer">
                            Hapus
                          </button>
                        </div>
                      </div>

                      <div className="max-h-60 overflow-y-auto divide-y divide-white/5 bg-[#161B22]">
                        {visibleNotifs.length === 0 ? (
                          <div className="text-center py-8 text-xs text-gray-500">
                            Tidak ada notifikasi aktif untuk peran Anda.
                          </div>
                        ) : (
                          visibleNotifs.map(n => (
                            <div key={n.id} className={`p-3 text-[11px] leading-relaxed transition ${n.read ? 'bg-transparent text-gray-400' : 'bg-blue-500/10 text-white font-medium'}`}>
                              <div className="flex justify-between items-center mb-0.5">
                                <span className="text-[9px] font-bold uppercase tracking-wider text-blue-400">{n.title}</span>
                                <span className="text-[9px] text-gray-500">{new Date(n.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                              </div>
                              <p className="text-gray-300">{n.message}</p>
                              {n.spkId && <span className="text-[8px] font-mono font-bold bg-[#0F1115] text-blue-400 px-1 py-0.5 rounded mt-1 inline-block border border-white/5">{n.spkId}</span>}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Status Badge & Role Switch Button */}
              <div className="flex items-center gap-2">
                <div className={`flex items-center gap-1.5 px-3 py-1.5 border rounded-xl text-xs font-semibold ${
                  currentRole === 'Pelapor'
                    ? 'bg-blue-500/10 border-blue-500/25 text-blue-400 animate-pulse'
                    : 'bg-white/5 border-white/10 text-gray-300'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${currentRole === 'Pelapor' ? 'bg-blue-400' : 'bg-green-400'}`}></span>
                  <span className="hidden sm:inline">Aktif:</span> {currentRole}
                </div>

                <button
                  onClick={() => setShowRoleModal(true)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-1 shadow-md shadow-blue-500/10 active:scale-95"
                  id="btn-switch-role-navbar"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  Ganti Peran
                </button>
              </div>
            </div>

          </div>
        </div>
      </nav>

      {/* DASHBOARD CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
        
        {currentRole === 'Pelapor' ? (
          /* Pelapor View: ONLY contains the SPK Form, NO Dashboard metrics, NO tab buttons, NO other tabs */
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="p-6 bg-[#161B22] border border-blue-500/20 rounded-3xl space-y-3 shadow-lg shadow-black/20">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-600/20 rounded-xl">
                  <UserCheck className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h2 className="font-extrabold text-white text-sm tracking-tight uppercase">Portal Pengajuan SPK (TEKNIK GIT)</h2>
                  <p className="text-[10px] text-gray-400">Selamat datang. Anda berada di portal khusus Pelapor Umum. Silakan buat instruksi kerja SPK baru dengan teliti.</p>
                </div>
              </div>
              
              {/* Firebase Guard message directly visible to Pelapor to explain quota guard */}
              <div className="p-3 bg-blue-500/5 text-blue-400 rounded-xl border border-blue-500/10 text-[10px] leading-relaxed flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                <span><strong>Sistem Kuota Terlindungi:</strong> Aplikasi menggunakan cache lokal terlindung. Penyegaran halaman (Refresh) tidak memakan kuota Firestore harian Anda. Data Anda aman 100% dari riset.</span>
              </div>
            </div>

            <SPKForm onAddSPK={handleAddSPK} currentUserName="Pelapor TEKNIK GIT" />
          </div>
        ) : (
          /* Staff/Management Roles: Full Dashboard and Monitoring Tabs */
          <>
            {/* Mobile Navigation Tabs */}
            <div className="flex md:hidden bg-[#161B22] border border-white/10 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('monitoring')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition text-center ${
                  activeTab === 'monitoring' ? 'bg-blue-600 text-white' : 'text-gray-400'
                }`}
              >
                Monitor
              </button>
              <button
                onClick={() => setActiveTab('pengajuan')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition text-center ${
                  activeTab === 'pengajuan' ? 'bg-blue-600 text-white' : 'text-gray-400'
                }`}
              >
                Buat SPK
              </button>
              <button
                onClick={() => setActiveTab('analisa')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition text-center ${
                  activeTab === 'analisa' ? 'bg-blue-600 text-white' : 'text-gray-400'
                }`}
              >
                Analisa
              </button>
              <button
                onClick={() => setActiveTab('backup')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition text-center ${
                  activeTab === 'backup' ? 'bg-blue-600 text-white' : 'text-gray-400'
                }`}
              >
                Backup
              </button>
            </div>

            {/* Dynamic Metric Dashboard cards */}
            <DashboardStats 
              spks={spks} 
              onSelectSPKDirectly={(spkId) => {
                setSelectedSpkId(spkId);
                setActiveTab('monitoring');
              }}
            />

            {/* Content Tabs */}
            {activeTab === 'monitoring' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Sidebar login & security control (4 cols) */}
                <div className="lg:col-span-4 space-y-6">
                  <RoleLogin
                    currentRole={currentRole}
                    onRoleChange={handleRoleChange}
                    pins={pins}
                    onChangePin={handleChangePin}
                    onLogout={() => {
                      setCurrentRole('Pelapor');
                      setActiveTab('pengajuan');
                      setShowRoleModal(true);
                    }}
                  />

                  {/* S.O.P Notice */}
                  <div className="bg-[#161B22] p-5 rounded-2xl text-gray-300 border border-white/5 space-y-3.5">
                    <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-wider">
                      <Shield className="w-4.5 h-4.5 text-blue-400" />
                      S.O.P Kebijakan Otoritas TEKNIK GIT
                    </div>
                    <div className="space-y-2.5 text-[11px] leading-relaxed">
                      <div className="flex gap-2 text-gray-400">
                        <span className="text-blue-400 font-bold">1.</span>
                        <span>Pelapor dari departemen mana saja dapat mengajukan SPK secara bebas.</span>
                      </div>
                      <div className="flex gap-2 text-gray-400">
                        <span className="text-blue-400 font-bold">2.</span>
                        <span><strong>Dilarang keras</strong> memulai tindakan perbaikan oleh teknisi jika status SPK belum bertanda <strong>Approved</strong> oleh Kepala Bagian (Head).</span>
                      </div>
                      <div className="flex gap-2 text-gray-400">
                        <span className="text-blue-400 font-bold">3.</span>
                        <span>Verifikasi penutupan tiket (Closed) mutlak membutuhkan validasi ganda dari Supervisor (SPV) dan Kepala Bagian (Head).</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* List & Task Center (8 cols) */}
                <div className="lg:col-span-8">
                  <SPKList
                    spks={spks}
                    currentRole={currentRole}
                    selectedSpkId={selectedSpkId}
                    onSelectSpk={(spk) => setSelectedSpkId(spk ? spk.id : undefined)}
                    onApproveDeptHead={handleApproveDeptHead}
                    onApproveSPK={handleApproveSPK}
                    onRejectSPK={handleRejectSPK}
                    onReportRepair={handleReportRepair}
                    onVerifySPV={handleVerifySPV}
                    onVerifyHead={handleVerifyHead}
                  />
                </div>

              </div>
            )}

            {activeTab === 'pengajuan' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                <div className="lg:col-span-8">
                  <SPKForm onAddSPK={handleAddSPK} currentUserName={`${currentRole} TEKNIK GIT`} />
                </div>
                
                {/* Quick stats panel */}
                <div className="lg:col-span-4 p-5 bg-[#161B22] border border-white/5 rounded-2xl space-y-4">
                  <h3 className="font-bold text-[#E0E0E0] text-sm">Status Antrean Terkini</h3>
                  
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl font-medium">
                      <span>Menunggu Approval Head:</span>
                      <span className="font-bold font-mono">{spks.filter(s => s.status === 'Pending').length} SPK</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl font-medium">
                      <span>Dalam Pengerjaan Teknisi:</span>
                      <span className="font-bold font-mono">{spks.filter(s => s.status === 'Approved').length} SPK</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded-xl font-medium">
                      <span>Tertunda Menunggu Sparepart:</span>
                      <span className="font-bold font-mono">{spks.filter(s => s.status === 'Menunggu Sparepart').length} SPK</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-purple-500/10 border border-purple-500/20 text-purple-400 rounded-xl font-medium">
                      <span>Menunggu Verifikasi Akhir:</span>
                      <span className="font-bold font-mono">{spks.filter(s => s.status === 'Menunggu Verifikasi').length} SPK</span>
                    </div>
                  </div>

                  <div className="text-[10px] text-gray-500 italic text-center pt-2 border-t border-white/5">
                    Pembaruan otomatis didukung oleh sistem log sinkronisasi realtime.
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'backup' && (
              <BackupPanel
                spks={spks}
                logs={logs}
                onTriggerBackup={handleTriggerBackup}
                onExportXLS={handleExportXLS}
                onResetData={handleResetData}
              />
            )}

            {activeTab === 'analisa' && (
              <DataAnalysisPanel spks={spks} />
            )}
          </>
        )}

      </main>

      {/* FOOTER */}
      <footer className="bg-[#0B0D11] border-t border-white/5 mt-20 py-8 text-center text-xs text-gray-500 font-medium">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p>© 2026 Sistem Surat Perintah Kerja (SPK) TEKNIK GIT. Hak Cipta Dilindungi Undang-Undang.</p>
          <p className="text-[10px] text-gray-600">Dual Sync Infrastructure: Firebase Firestore Security & Google Workspace API Connector.</p>
        </div>
      </footer>

      {/* Startup Role Selection Modal popup */}
      <RoleLoginModal 
        isOpen={showRoleModal} 
        pins={pins} 
        onAuthenticate={handleAuthenticate} 
      />

    </div>
  );
}
