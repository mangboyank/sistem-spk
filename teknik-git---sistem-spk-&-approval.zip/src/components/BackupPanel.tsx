import React, { useState } from 'react';
import { SPK, BackupLog } from '../types';
import { Database, FileSpreadsheet, Server, CloudLightning, Check, RefreshCcw, Download, Terminal, Settings, AlertTriangle, Trash2 } from 'lucide-react';

interface BackupPanelProps {
  spks: SPK[];
  logs: BackupLog[];
  onTriggerBackup: (type: 'Firebase' | 'Google Spreadsheet') => void;
  onExportXLS: () => void;
  onResetData?: () => void;
}

export default function BackupPanel({ spks, logs, onTriggerBackup, onExportXLS, onResetData }: BackupPanelProps) {
  const [activeTab, setActiveTab] = useState<'firebase' | 'sheets'>('sheets');
  const [isSyncing, setIsSyncing] = useState<string | null>(null);

  const handleSync = (type: 'Firebase' | 'Google Spreadsheet') => {
    setIsSyncing(type);
    setTimeout(() => {
      onTriggerBackup(type);
      setIsSyncing(null);
    }, 1500);
  };

  return (
    <div className="bg-[#161B22] rounded-2xl border border-white/5 shadow-lg overflow-hidden" id="backup-schema-panel">
      {/* Header */}
      <div className="bg-[#0F1115] p-5 text-white flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-white/10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-green-400" />
            <h2 className="font-bold text-base">Skema Sinkronisasi & Backup Data</h2>
          </div>
          <p className="text-xs text-gray-400">Arsitektur penyimpanan ganda terdistribusi aman: Firebase Firestore & Google Spreadsheet.</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-400 rounded-full text-[10px] font-mono">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            DATABASE ONLINE
          </div>
          <button
            onClick={onExportXLS}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-1 transition active:scale-95 cursor-pointer shadow-md shadow-blue-500/10"
            id="btn-backup-export"
          >
            <Download className="w-3.5 h-3.5" />
            Download XLS
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/5 bg-[#0F1115]">
        <button
          onClick={() => setActiveTab('sheets')}
          className={`flex-1 py-3 px-4 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition cursor-pointer ${
            activeTab === 'sheets'
              ? 'border-green-500 bg-[#161B22] text-green-400'
              : 'border-transparent text-gray-500 hover:text-white hover:bg-white/[0.01]'
          }`}
          id="tab-google-sheets"
        >
          <FileSpreadsheet className="w-4 h-4 text-green-400" />
          Google Spreadsheet Backup (Live Row Sync)
        </button>
        <button
          onClick={() => setActiveTab('firebase')}
          className={`flex-1 py-3 px-4 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition cursor-pointer ${
            activeTab === 'firebase'
              ? 'border-blue-500 bg-[#161B22] text-blue-400'
              : 'border-transparent text-gray-500 hover:text-white hover:bg-white/[0.01]'
          }`}
          id="tab-firebase"
        >
          <Database className="w-4 h-4 text-blue-400" />
          Firebase Cloud Firestore (Primary DB)
        </button>
      </div>

      <div className="p-5">
        {activeTab === 'sheets' ? (
          /* Google Spreadsheet Content */
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <h3 className="text-xs font-bold text-white flex items-center gap-1">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Tampilan Spreadsheet Tersinkronisasi
                </h3>
                <p className="text-[11px] text-gray-400">Merepresentasikan sheet cloud Google Workspace yang terhubung secara realtime.</p>
              </div>

              <div className="flex gap-2">
                <button
                  disabled={isSyncing !== null}
                  onClick={() => handleSync('Google Spreadsheet')}
                  className="px-3.5 py-2 bg-green-500/10 hover:bg-green-500/20 border border-green-500/20 text-green-400 text-xs font-bold rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <RefreshCcw className={`w-3.5 h-3.5 ${isSyncing === 'Google Spreadsheet' ? 'animate-spin' : ''}`} />
                  {isSyncing === 'Google Spreadsheet' ? 'Mencadangkan...' : 'Sync ke Google Sheets'}
                </button>
              </div>
            </div>

            {/* Google Sheets Simulated Grid View */}
            <div className="border border-white/10 rounded-xl overflow-hidden shadow-md">
              {/* Sheets top bar */}
              <div className="bg-[#107c41]/80 text-white px-3.5 py-1.5 text-[10px] font-bold font-sans flex items-center justify-between">
                <span>Laporan_SPK_TEKNIK_GIT_Backup.xlsx - Google Sheets</span>
                <span className="bg-[#0b5c30]/90 text-green-100 px-1.5 py-0.5 rounded text-[9px]">Tersimpan ke Drive</span>
              </div>
              
              {/* Excel Columns */}
              <div className="overflow-x-auto max-h-[220px]">
                <table className="w-full text-[10px] text-gray-300 border-collapse">
                  <thead>
                    <tr className="bg-[#0F1115] text-gray-400 text-left border-b border-white/5 select-none">
                      <th className="p-1.5 border-r border-white/5 text-center w-8"></th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">A</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">B</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">C</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">D</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">E</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">F</th>
                      <th className="p-1.5 border-r border-white/5 font-bold font-mono">G</th>
                    </tr>
                    <tr className="bg-[#161B22] text-[#E0E0E0] border-b border-white/10 font-bold">
                      <td className="p-1.5 border-r border-white/5 bg-[#0F1115] text-center text-gray-500 font-mono">1</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">No SPK</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Tanggal Pengajuan</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Nama Mesin</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Diajukan Oleh</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Bagian</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Status</td>
                      <td className="p-1.5 border-r border-white/5 text-green-400">Tindak Perbaikan</td>
                    </tr>
                  </thead>
                  <tbody>
                    {spks.map((spk, idx) => (
                      <tr key={spk.id} className="border-b border-white/5 hover:bg-white/[0.01] transition">
                        <td className="p-1.5 border-r border-white/5 bg-[#0F1115] text-center text-gray-500 font-mono">{idx + 2}</td>
                        <td className="p-1.5 border-r border-white/5 font-mono font-semibold text-white">{spk.id}</td>
                        <td className="p-1.5 border-r border-white/5 font-mono text-gray-400">{spk.tanggalPengajuan}</td>
                        <td className="p-1.5 border-r border-white/5 font-semibold text-gray-300">{spk.namaMesin}</td>
                        <td className="p-1.5 border-r border-white/5 text-gray-400">{spk.diajukanOleh}</td>
                        <td className="p-1.5 border-r border-white/5 text-gray-400">{spk.bagian}</td>
                        <td className="p-1.5 border-r border-white/5">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${
                            spk.status === 'Closed' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                            spk.status === 'Rejected' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                            spk.status === 'Menunggu Sparepart' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                            spk.status === 'Menunggu Verifikasi' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                            spk.status === 'Approved' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          }`}>
                            {spk.status}
                          </span>
                        </td>
                        <td className="p-1.5 border-r border-white/5 text-gray-500 italic max-w-[200px] truncate">
                          {spk.tindakPerbaikan || '(Belum dikerjakan)'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          /* Firebase Firestore Cloud DB Content */
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <h3 className="text-xs font-bold text-white flex items-center gap-1">
                  <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
                  Visualisasi Skema Firestore
                </h3>
                <p className="text-[11px] text-gray-400">Peta relasi database NoSQL terstruktur yang digunakan aplikasi ini secara cloud.</p>
              </div>

              <div className="flex gap-2">
                <button
                  disabled={isSyncing !== null}
                  onClick={() => handleSync('Firebase')}
                  className="px-3.5 py-2 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 text-blue-400 text-xs font-bold rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <RefreshCcw className={`w-3.5 h-3.5 ${isSyncing === 'Firebase' ? 'animate-spin' : ''}`} />
                  {isSyncing === 'Firebase' ? 'Sinkronisasi...' : 'Push Manual ke Firestore'}
                </button>
              </div>
            </div>

            {/* Firestore Visual Schema */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Coll 1: spks */}
              <div className="border border-white/5 rounded-xl p-3.5 bg-[#0F1115] hover:border-blue-500/20 transition">
                <div className="flex items-center gap-1.5 text-blue-400 font-bold font-mono text-[11px] mb-2">
                  <Database className="w-3.5 h-3.5" />
                  koleksi: /spks/
                </div>
                <div className="text-[10px] space-y-1.5 text-gray-400">
                  <p>Menyimpan data Surat Perintah Kerja & detail pengerjaan perbaikan.</p>
                  <div className="bg-[#161B22] border border-white/5 rounded p-2 text-[9px] font-mono leading-relaxed text-gray-300">
                    id: string (No SPK)<br/>
                    tanggalPengajuan: string<br/>
                    status: string (enum)<br/>
                    verifiedBySPV: boolean<br/>
                    verifiedByHead: boolean
                  </div>
                </div>
              </div>

              {/* Coll 2: notifications */}
              <div className="border border-white/5 rounded-xl p-3.5 bg-[#0F1115] hover:border-blue-500/20 transition">
                <div className="flex items-center gap-1.5 text-blue-400 font-bold font-mono text-[11px] mb-2">
                  <Database className="w-3.5 h-3.5" />
                  koleksi: /notifications/
                </div>
                <div className="text-[10px] space-y-1.5 text-gray-400">
                  <p>Mendukung notifikasi real-time bagi penanggung jawab (Teknik/SPV/Head).</p>
                  <div className="bg-[#161B22] border border-white/5 rounded p-2 text-[9px] font-mono leading-relaxed text-gray-300">
                    id: string<br/>
                    title: string<br/>
                    message: string<br/>
                    role: string ('Teknik'|'SPV'|'Head')<br/>
                    read: boolean
                  </div>
                </div>
              </div>

              {/* Coll 3: pins */}
              <div className="border border-white/5 rounded-xl p-3.5 bg-[#0F1115] hover:border-blue-500/20 transition">
                <div className="flex items-center gap-1.5 text-blue-400 font-bold font-mono text-[11px] mb-2">
                  <Database className="w-3.5 h-3.5" />
                  koleksi: /pins/
                </div>
                <div className="text-[10px] space-y-1.5 text-gray-400">
                  <p>Menyimpan hashing atau PIN akses penanggung jawab terenkripsi.</p>
                  <div className="bg-[#161B22] border border-white/5 rounded p-2 text-[9px] font-mono leading-relaxed text-gray-300">
                    Teknik: string (PIN)<br/>
                    SPV: string (PIN)<br/>
                    Head: string (PIN)<br/>
                    updatedAt: timestamp
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Audit Sync Logs Terminal */}
        <div className="mt-5 border border-white/5 rounded-2xl bg-slate-950 p-4 font-mono text-xs text-[#E0E0E0] space-y-3 shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-gray-500">
            <span className="flex items-center gap-1.5 text-[10px]">
              <Terminal className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              LOG AKTIVITAS SINKRONISASI BACKUP
            </span>
            <span className="text-[9px] bg-[#0F1115] px-1.5 py-0.5 rounded text-blue-400 border border-white/5">Auto-Sync On</span>
          </div>

          <div className="space-y-2 max-h-[120px] overflow-y-auto text-[10px]">
            {logs.length === 0 ? (
              <p className="text-gray-600 italic text-center py-2">Belum ada log sinkronisasi tercatat.</p>
            ) : (
              logs.map(log => (
                <div key={log.id} className="flex items-start gap-2 leading-relaxed border-b border-slate-900/50 pb-1.5">
                  <span className="text-gray-600 shrink-0">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                  <span className={`font-bold shrink-0 ${log.type === 'Firebase' ? 'text-blue-400' : 'text-green-400'}`}>
                    {log.type}
                  </span>
                  <span className={`px-1 rounded text-[8px] font-bold shrink-0 ${log.status === 'Sukses' ? 'bg-green-950 text-green-400 border border-green-500/20' : 'bg-red-950 text-red-400 border border-red-500/20'}`}>
                    {log.status}
                  </span>
                  <span className="text-gray-500 font-medium">({log.recordsSynced} data)</span>
                  <span className="text-gray-300">{log.details}</span>
                </div>
              ))
            )}
          </div>
        </div>
        {/* Danger Zone: Reset Data */}
        <div className="mt-5 border border-red-500/10 rounded-2xl bg-red-500/[0.02] p-4 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-red-400 flex items-center gap-1.5 uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-red-500" />
                Zona Berbahaya (Persiapan Publish)
              </h4>
              <p className="text-[11px] text-gray-400">
                Gunakan tombol di samping untuk menghapus seluruh data transaksi SPK, notifikasi, dan log di memori browser Anda sebelum meluncurkan aplikasi ke produksi.
              </p>
            </div>
            <button
              onClick={() => {
                if (confirm("Apakah Anda yakin ingin menghapus semua data SPK, notifikasi, dan log? Tindakan ini tidak dapat dibatalkan.")) {
                  onResetData?.();
                }
              }}
              className="px-3.5 py-2 bg-red-600/10 hover:bg-red-600 hover:text-white border border-red-600/20 text-red-400 text-xs font-bold rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Kosongkan Semua Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
